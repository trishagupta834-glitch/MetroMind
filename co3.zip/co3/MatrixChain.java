package co3;

public class MatrixChain {
    public static String findOptimalMultiplicationOrder(int[] dimensions) {
        int n = dimensions.length - 1;
        int[][] dp = new int[n][n], split = new int[n][n];
        for (int length = 2; length <= n; length++)
            for (int i = 0; i + length <= n; i++) {
                int j = i + length - 1;
                dp[i][j] = Integer.MAX_VALUE;
                for (int k = i; k < j; k++) {
                    int cost = dp[i][k] + dp[k + 1][j] + dimensions[i] * dimensions[k + 1] * dimensions[j + 1];
                    if (cost < dp[i][j]) { dp[i][j] = cost; split[i][j] = k; }
                }
            }
        return n == 0 ? "" : order(split, 0, n - 1) + " | Cost: " + dp[0][n - 1];
    }

    static String order(int[][] split, int i, int j) {
        if (i == j) return "" + (char)('A' + i);
        int k = split[i][j];
        return "(" + order(split, i, k) + " * " + order(split, k + 1, j) + ")";
    }

    public static int minCost(int[] dimensions) {
        int n = dimensions.length - 1;
        int[][] dp = new int[n][n];
        for (int length = 2; length <= n; length++)
            for (int i = 0; i + length <= n; i++) {
                int j = i + length - 1;
                dp[i][j] = Integer.MAX_VALUE;
                for (int k = i; k < j; k++)
                    dp[i][j] = Math.min(dp[i][j], dp[i][k] + dp[k + 1][j]
                            + dimensions[i] * dimensions[k + 1] * dimensions[j + 1]);
            }
        return n == 0 ? 0 : dp[0][n - 1];
    }

    public static void main(String[] args) {
        System.out.println(minCost(new int[]{10, 20, 30, 40}));
    }
}
