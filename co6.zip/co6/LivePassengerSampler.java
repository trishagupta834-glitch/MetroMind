package co6;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class LivePassengerSampler {
    private final int capacity;
    private final Random random = new Random();
    private final List<String> reservoir = new ArrayList<>();
    private long eventsSeen;

    public LivePassengerSampler(int capacity) {
        if (capacity < 0) throw new IllegalArgumentException("Sample size cannot be negative.");
        this.capacity = capacity;
    }

    public void accept(String event) {
        eventsSeen++;
        if (reservoir.size() < capacity) {
            reservoir.add(event);
            return;
        }
        if (capacity == 0) return;
        long position = random.nextLong(eventsSeen);
        if (position < capacity) reservoir.set((int) position, event);
    }

    public long eventsSeen() {
        return eventsSeen;
    }

    public List<String> sample() {
        return new ArrayList<>(reservoir);
    }
}