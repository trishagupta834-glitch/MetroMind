package co6;

import java.math.BigInteger;
import java.util.Random;

public class PrimeBatchValidator {
    private static final BigInteger TWO = BigInteger.valueOf(2);
    private static final BigInteger THREE = BigInteger.valueOf(3);

    public static boolean isProbablePrime(BigInteger value, int rounds) {
        if (rounds <= 0) throw new IllegalArgumentException("Miller-Rabin rounds must be positive.");
        if (value.compareTo(TWO) < 0) return false;
        if (value.equals(TWO) || value.equals(THREE)) return true;
        if (!value.testBit(0)) return false;

        BigInteger oddPart = value.subtract(BigInteger.ONE);
        int powersOfTwo = oddPart.getLowestSetBit();
        oddPart = oddPart.shiftRight(powersOfTwo);
        BigInteger upperExclusive = value.subtract(BigInteger.ONE);
        Random random = new Random();

        for (int round = 0; round < rounds; round++) {
            BigInteger base;
            do {
                base = new BigInteger(value.bitLength(), random);
            } while (base.compareTo(TWO) < 0 || base.compareTo(upperExclusive) >= 0);
            BigInteger witness = base.modPow(oddPart, value);
            if (witness.equals(BigInteger.ONE) || witness.equals(value.subtract(BigInteger.ONE))) continue;
            boolean probablyPrime = false;
            for (int power = 1; power < powersOfTwo; power++) {
                witness = witness.multiply(witness).mod(value);
                if (witness.equals(value.subtract(BigInteger.ONE))) {
                    probablyPrime = true;
                    break;
                }
            }
            if (!probablyPrime) return false;
        }
        return true;
    }
}