package co6;

import java.util.Arrays;
import java.util.LongSummaryStatistics;

public class TransportStatsReducer {
    public static class Statistics {
        public final long count;
        public final long total;
        public final long minimum;
        public final long maximum;
        public final double average;

        Statistics(LongSummaryStatistics summary) {
            count = summary.getCount();
            total = summary.getSum();
            minimum = count == 0 ? 0 : summary.getMin();
            maximum = count == 0 ? 0 : summary.getMax();
            average = summary.getAverage();
        }
    }

    public static Statistics summarize(long[] passengerCounts) {
        return new Statistics(Arrays.stream(passengerCounts).parallel().summaryStatistics());
    }
}