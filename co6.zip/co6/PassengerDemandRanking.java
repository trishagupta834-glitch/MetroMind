package co6;

import java.util.Random;

public class PassengerDemandRanking {
    public static class ServiceRecord {
        public final String service;
        public final long passengers;

        public ServiceRecord(String service, long passengers) {
            this.service = service;
            this.passengers = passengers;
        }
    }

    public static void sortByDemand(ServiceRecord[] records) {
        quickSort(records, 0, records.length - 1, new Random());
    }

    private static void quickSort(ServiceRecord[] records, int low, int high, Random random) {
        if (low >= high) return;
        int pivot = low + random.nextInt(high - low + 1);
        swap(records, pivot, high);
        int boundary = low;
        for (int i = low; i < high; i++)
            if (comesBefore(records[i], records[high])) swap(records, boundary++, i);
        swap(records, boundary, high);
        quickSort(records, low, boundary - 1, random);
        quickSort(records, boundary + 1, high, random);
    }

    private static boolean comesBefore(ServiceRecord first, ServiceRecord second) {
        if (first.passengers != second.passengers) return first.passengers > second.passengers;
        return first.service.compareToIgnoreCase(second.service) < 0;
    }

    private static void swap(ServiceRecord[] records, int first, int second) {
        ServiceRecord value = records[first];
        records[first] = records[second];
        records[second] = value;
    }
}