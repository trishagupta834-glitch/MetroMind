package co6;

public class ParallelServicePlanner {
    public static double[] brentBounds(long work, long span, int processors) {
        if (work < 0 || span < 0 || span > work)
            throw new IllegalArgumentException("Require 0 <= span <= work.");
        if (processors <= 0) throw new IllegalArgumentException("Worker count must be positive.");
        double workPerProcessor = (double) work / processors;
        return new double[]{workPerProcessor, workPerProcessor + span};
    }
}