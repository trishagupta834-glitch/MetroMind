package co5;

public class SatToClique {
    public static int countCliqueGraphNodes(int[][] clauses) {
        int nodes = 0;
        for (int[] clause : clauses) nodes += clause.length;
        return nodes;
    }

    public static boolean compatible(int a, int b) {
        return a != -b;
    }
}
