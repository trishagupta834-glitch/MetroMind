package co5;

import java.util.ArrayList;
import java.util.List;

public class VertexCoverApprox {
    public static List<Integer> cover(int[][] edges) {
        boolean[] used = new boolean[edges.length];
        List<Integer> cover = new ArrayList<>();
        for (int i = 0; i < edges.length; i++) {
            if (used[i]) continue;
            int a = edges[i][0], b = edges[i][1];
            cover.add(a);
            cover.add(b);
            for (int j = i; j < edges.length; j++)
                if (edges[j][0] == a || edges[j][1] == a || edges[j][0] == b || edges[j][1] == b) used[j] = true;
        }
        return cover;
    }
}
