package co5;

public class CliqueIndependentVertexCover {
    public static int independentSetSizeFromClique(int graphNodes, int cliqueSize) {
        return cliqueSize;
    }

    public static int vertexCoverSizeFromIndependentSet(int graphNodes, int independentSize) {
        return graphNodes - independentSize;
    }
}
