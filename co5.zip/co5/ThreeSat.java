package co5;

public class ThreeSat {
    public static boolean satisfiable(int vars, int[][] clauses) {
        for (int mask = 0; mask < (1 << vars); mask++) {
            boolean ok = true;
            for (int[] c : clauses) {
                boolean clause = false;
                for (int literal : c) {
                    int var = Math.abs(literal) - 1;
                    boolean value = ((mask >> var) & 1) == 1;
                    clause |= literal > 0 ? value : !value;
                }
                ok &= clause;
            }
            if (ok) return true;
        }
        return false;
    }
}
